package ui;


import javax.swing.*;

/**
 * Main to run agenda app
 */
public class Main extends JFrame {
    public static void main(String[] args) {
        new YearProcess();
    }
}
